﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel;
using System.Configuration;
using System.Data.Entity.Infrastructure;

namespace CodeFirstApproachEx
{

    class amgogu_EmployeeContext : DbContext 
    {
        public amgogu_EmployeeContext() : base("amgogu1") { }

        //EntitySet
        public DbSet<amgogu_Employee1> Employees { get; set; }
    }

    //DBContext
    //A DbContext instance represents a combination of the Unit Of Work and Repository patterns 
    //such that it can be used to query from a database and group together changes
    //that will then be written back to the store as a unit. 

}
