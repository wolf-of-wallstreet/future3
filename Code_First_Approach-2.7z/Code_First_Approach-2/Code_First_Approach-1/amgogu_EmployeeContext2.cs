﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel;
using System.Configuration;
using System.Data.Entity.Infrastructure;

namespace Code_First_Approach_1
{
    class amgogu_EmployeeContext2 : DbContext
    {
        public amgogu_EmployeeContext2() : base("amgogu2") { }

        //EntitySet
        public DbSet<amgogu_Employee2> Employees { get; set; }
    }
}
