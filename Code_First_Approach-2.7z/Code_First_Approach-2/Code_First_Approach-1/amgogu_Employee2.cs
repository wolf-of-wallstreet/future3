﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel;
using System.Configuration;
using System.Data.Entity.Infrastructure;
using System.ComponentModel.DataAnnotations;

namespace Code_First_Approach_1
{
    class amgogu_Employee2
    {
        [Key]
        public int ID { get; set; }//this is will the primary key in the table as the data type is integer identity will applied on this field         
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DOB { get; set; }
        public string Designation { get; set; }
    }
}
