﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Code_First_Approach_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        amgogu_EmployeeContext2 empContext;
        amgogu_Employee2 emp;

        public MainWindow()
        {
            InitializeComponent();
            empContext = new amgogu_EmployeeContext2();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            if (txt_Full_Name.Text == "" || txt_Last_Name.Text == "" || txt_Designation.Text == "(Select)")
            {
                MessageBox.Show("Please provide all the details");
            }
            else
            {
                try
                {
                    emp = new amgogu_Employee2();
                    emp.FirstName = txt_Full_Name.Text;
                    emp.LastName = txt_Last_Name.Text;
                    emp.DOB = Convert.ToDateTime(txt_Date_Picker.Text);
                    emp.Designation = txt_Designation.Text;

                    empContext.Employees.Add(emp);//Adds the employee object to the entity set
                    empContext.SaveChanges();//Commits the change to the database;

                    MessageBox.Show("Employee Record Inserted");
                    ResetFields();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    emp = null;
                }
            }
        }
        //  ------------------
        private void ResetFields()
        {
            txt_Full_Name.Text = "";
            txt_Last_Name.Text = "";
            txt_Date_Picker.Text = "";
            txt_Designation.Text="";
            
        }
    };
}
